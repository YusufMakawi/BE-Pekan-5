# pertemuan-5
Membuat GET dan mendapatkan data dari database
